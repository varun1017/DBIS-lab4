Instructions to run the project:

Open frontend directory in the terminal and run: npm start
Open backend directory in the terminal and run: npm run dev

We have submitted without node_modules in both the above directories, so to run the code install the appropriate node_modules. 

Note: We have used .env for security and read the user and database credentials from that file and used this data in the db.js file in backend directory.

References:
1)https://www.youtube.com/watch?v=z20ZBv7HLJU&ab_channel=LesterFernandez